package com.purna.libraries;

public interface Constants {
    String PROPERTIES_FILE_PATH = "./src/test/resources/other/config.properties";

}
