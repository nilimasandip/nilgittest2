package com.purna.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ManufacturingCreateCustomerPage {
	
	public ManufacturingCreateCustomerPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	
	@FindBy(id="customerName")
	public WebElement txtbox_customerName;
	
	@FindBy(id="cust_contact_no")
	public WebElement txtbox_customerContactNo;
	
	@FindBy(id="cust_address_bill")
	public WebElement txtbox_billingAddress;
	
	@FindBy(id="cust_address_ship")
	public WebElement txtbox_shippingAddress;
	
	@FindBy(id="custEmail")
	public WebElement txtbox_emailId;
	
	@FindBy(id="custContactPerson")
	public WebElement txtbox_contactPerson;
	
	@FindBy(id="custContactPersonContact")
	public WebElement txtbox_ContactPersonNo;
	
	@FindBy(xpath="//input[@name='custGstNo']")
	public WebElement txtbox_GSTNo;
	
	@FindBy(xpath="//input[@name='custPanNo']")
	public WebElement txtbox_PanNo;
	
	@FindBy(xpath="//input[@name='custVendorCode']")
	public WebElement txtbox_vendorCode;
	
	@FindBy(xpath="//button[@class='btn-responsive btn btn-primary']")
	public WebElement btn_manSave;
	

}
