package com.purna.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ManufacturingCustomerDashboardPage {
	

	public ManufacturingCustomerDashboardPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath="//a[@href=\"create_customer.php\"]")
	public WebElement btn_addCustomer;
	
	@FindBy(xpath="//a[@href='update_customer.php?id=1']")
	public WebElement btn_edit;

}
