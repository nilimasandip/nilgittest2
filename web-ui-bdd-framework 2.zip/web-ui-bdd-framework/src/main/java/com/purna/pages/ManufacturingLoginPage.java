package com.purna.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ManufacturingLoginPage {
	
	public ManufacturingLoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
    @FindBy(id="inputEmail3")
    public WebElement txtbox_AdminID;

    @FindBy(id="inputPassword3")
    public WebElement txtbox_MANpassword;

    @FindBy(name="submit")
    public WebElement btn_SignIn;

}
