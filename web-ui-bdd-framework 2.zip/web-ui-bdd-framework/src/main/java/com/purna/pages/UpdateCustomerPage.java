package com.purna.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UpdateCustomerPage {
	
	public UpdateCustomerPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	
	@FindBy(id="cust_contact_no")
	public WebElement txtbox_updatecustContactNo;

	@FindBy(xpath="//button[text()='Save']")
	public WebElement btn_updateSave;
}
