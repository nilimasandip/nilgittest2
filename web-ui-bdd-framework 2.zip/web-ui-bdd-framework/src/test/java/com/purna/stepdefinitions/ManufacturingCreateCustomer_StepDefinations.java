package com.purna.stepdefinitions;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.purna.libraries.TestContext;
import com.purna.libraries.Utilities;
import com.purna.pages.CustDashboardPage;
import com.purna.pages.CustomerPage;
import com.purna.pages.DashboardPage;
import com.purna.pages.HomePage;
import com.purna.pages.ManufacturingCreateCustomerPage;
import com.purna.pages.ManufacturingCustomerDashboardPage;
import com.purna.pages.UpdateCustomerPage;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ManufacturingCreateCustomer_StepDefinations {
	
	private WebDriver driver;
    private TestContext testContext;
	private HomePage onhomePage;
	private ManufacturingCreateCustomerPage onManufacturingCreateCustomerPage;
	private ManufacturingCustomerDashboardPage onManufacturingCustomerDashboardPage;
	Utilities utils;
	UpdateCustomerPage onUpdateCustomerPage;
	
	 public ManufacturingCreateCustomer_StepDefinations(TestContext context)
	    {
	        testContext = context;
	        driver = testContext.getDriver();
	        onhomePage = new HomePage(driver);
	        onManufacturingCreateCustomerPage = new ManufacturingCreateCustomerPage(driver);
	        onManufacturingCustomerDashboardPage = new ManufacturingCustomerDashboardPage(driver);
	        utils = new Utilities();
	        onUpdateCustomerPage =new UpdateCustomerPage(driver);
	    }
	
	
	@When("User clicks on ManufacturingCustomer link")
	public void user_clicks_on_manufacturing_customer_link() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		onhomePage.link_customer.click();
	}
	
	@When("User clicks clicks on Add customer button")
	public void user_clicks_clicks_on_add_customer_button() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		onManufacturingCustomerDashboardPage.btn_addCustomer.click();
	}
	@When("User enters the Manufacturingcustomer details")
	public void user_enters_the_manufacturingcustomer_details(DataTable table) {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
	    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
	    // Double, Byte, Short, Long, BigInteger or BigDecimal.
	    //
	    // For other transformations you can register a DataTableType.
	    //throw new io.cucumber.java.PendingException();
		
		List<List<String>> data = table.asLists();
		onManufacturingCreateCustomerPage.txtbox_customerName.sendKeys(data.get(0).get(0));
		onManufacturingCreateCustomerPage.txtbox_customerContactNo.sendKeys(data.get(0).get(1));
		onManufacturingCreateCustomerPage.txtbox_billingAddress.sendKeys(data.get(0).get(2));
		onManufacturingCreateCustomerPage.txtbox_shippingAddress.sendKeys(data.get(0).get(3));
		onManufacturingCreateCustomerPage.txtbox_emailId.sendKeys(data.get(0).get(4));
		onManufacturingCreateCustomerPage.txtbox_contactPerson.sendKeys(data.get(0).get(5));
		onManufacturingCreateCustomerPage.txtbox_ContactPersonNo.sendKeys(data.get(0).get(6));
		onManufacturingCreateCustomerPage.txtbox_GSTNo.sendKeys(data.get(0).get(7));
		onManufacturingCreateCustomerPage.txtbox_PanNo.sendKeys(data.get(0).get(8));
		onManufacturingCreateCustomerPage.txtbox_vendorCode.sendKeys(data.get(0).get(9));
		
		
	}
	@When("User clicks on ManSave button")
	public void user_clicks_on_man_save_button() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		onManufacturingCreateCustomerPage.btn_manSave.click();
		
	}
	@When("User click on ManOk button on popup")
	public void user_click_on_man_ok_button_on_popup() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}
	@When("User click on ManOk2 button on popup")
	public void user_click_on_man_ok2_button_on_popup() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		
		driver.switchTo().alert().accept();
		
	}
	
	@Then("User verfies that Mancustomer is created")
	public void user_verfies_that_mancustomer_is_created() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		 driver.navigate().refresh();
		 Assert.assertEquals(driver.findElement(By.xpath("//td[text()='CodeNameHomes']")).getText(), "CodeNameHomes");
		 
		
	}
	
	@When("User clicks on ManEdit button")
	public void user_clicks_on_man_edit_button() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		onManufacturingCustomerDashboardPage.btn_edit.click();
		
	}
	
	@When("User Upadate contact No.")
	public void user_upadate_contact_no() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		onUpdateCustomerPage.txtbox_updatecustContactNo.clear();
		onUpdateCustomerPage.txtbox_updatecustContactNo.sendKeys("0123456789");
		
	}
	
	@When("User clicks on UpdateSave button")
	public void user_clicks_on_update_save_button() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		
		onUpdateCustomerPage.btn_updateSave.click();
	}
	
	
	@Then("User verfies that contact no is updated")
	public void user_verfies_that_contact_no_is_updated() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		
		driver.navigate().refresh();
		Assert.assertEquals(driver.findElement(By.xpath("//td[text()='0123456789']")).getText(), "0123456789");
	}


}
