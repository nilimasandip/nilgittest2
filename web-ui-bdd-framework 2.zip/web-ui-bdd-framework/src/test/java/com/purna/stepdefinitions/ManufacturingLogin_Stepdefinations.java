package com.purna.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.purna.libraries.TestContext;
//import com.purna.pages.LoginPage;
import com.purna.pages.ManufacturingLoginPage;

//import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ManufacturingLogin_Stepdefinations {
	
	private WebDriver driver;
    private ManufacturingLoginPage onManufacturingLoginPage;
    private TestContext testContext;
    
    public ManufacturingLogin_Stepdefinations(TestContext context)
    {
        testContext = context;
        driver = testContext.getDriver();
        onManufacturingLoginPage = new ManufacturingLoginPage(driver);
    }
	
	
	@When("User on Index Page enters valid username and password")
	public void user_on_index_page_enters_valid_username_and_password() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		
		
		onManufacturingLoginPage.txtbox_AdminID.sendKeys(testContext.getMapTestData().get("username"));
		onManufacturingLoginPage.txtbox_MANpassword.sendKeys(testContext.getMapTestData().get("password"));
	}
	
	@When("User on Index Page enters invalid username and password")
	public void user_on_index_page_enters_invalid_username_and_password() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		onManufacturingLoginPage.txtbox_AdminID.sendKeys(testContext.getMapTestData().get("username"));
		onManufacturingLoginPage.txtbox_MANpassword.sendKeys(testContext.getMapTestData().get("password"));
	}
	
	@When("User clicks on Sign in button")
	public void user_clicks_on_sign_in_button() {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new io.cucumber.java.PendingException();
		onManufacturingLoginPage.btn_SignIn.click();
	}
	@Then("User should navigates to home page")
	public void user_should_navigates_to_home_page() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		 Assert.assertEquals(driver.getCurrentUrl(), testContext.getMapTestData().get("expectedUrl"));
	}

	@Then("User should navigates to Index page")
	public void user_should_navigates_to_index_page() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		
		Assert.assertEquals(driver.getCurrentUrl(), testContext.getMapTestData().get("expectedUrl"));
	}
}
